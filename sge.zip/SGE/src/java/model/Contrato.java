/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

/**
 *
 * @author Paulo farias
 */
public class Contrato {
    private int idContrato;
    private String dataMatricula;
    private double valorTotal;
    private int status;
    private Responsavel responsavel;
    private Funcionario funcionario;

    public int getIdContrato() {
        return idContrato;
    }

    public void setIdContrato(int idContrato) {
        this.idContrato = idContrato;
    }

    public String getDataMatricula() {
        return dataMatricula;
    }

    public void setDataMatricula(String dataMatricula) {
        this.dataMatricula = dataMatricula;
    }

    public double getValorTotal() {
        return valorTotal;
    }

    public void setValorTotal(double valorTotal) {
        this.valorTotal = valorTotal;
    }

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    public Responsavel getResponsavel() {
        return responsavel;
    }

    public void setResponsavel(Responsavel responsavel) {
        this.responsavel = responsavel;
    }

    public Funcionario getFuncionario() {
        return funcionario;
    }

    public void setFuncionario(Funcionario funcionario) {
        this.funcionario = funcionario;
    }

    public Contrato() {
    }

    public Contrato(int idContrato, String dataMatricula, double valorTotal, int status, Responsavel responsavel, Funcionario funcionario) {
        this.idContrato = idContrato;
        this.dataMatricula = dataMatricula;
        this.valorTotal = valorTotal;
        this.status = status;
        this.responsavel = responsavel;
        this.funcionario = funcionario;
    }
    
    
    
    
    
    
}
