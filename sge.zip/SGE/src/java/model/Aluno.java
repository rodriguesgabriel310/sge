/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import java.util.ArrayList;
import persistencia.AlunoDAO;

/**
 *
 * @author Paulo farias
 */
public class Aluno {
    
    private int idaluno;
    private String nome;
    private String cpf;
    private String dataNascimento;
    private String sexo;
    private String obsMedicas;
    private String nomeAutorizado;
    private String parentesco;
    private String telefone;
    private Turma turma;

    public int getIdaluno() {
        return idaluno;
    }

    public void setIdaluno(int idaluno) {
        this.idaluno = idaluno;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getCpf() {
        return cpf;
    }

    public void setCpf(String cpf) {
        this.cpf = cpf;
    }

    public String getDataNascimento() {
        return dataNascimento;
    }

    public void setDataNascimento(String dataNascimento) {
        this.dataNascimento = dataNascimento;
    }

    public String getSexo() {
        return sexo;
    }

    public void setSexo(String sexo) {
        this.sexo = sexo;
    }

    public String getObsMedicas() {
        return obsMedicas;
    }

    public void setObsMedicas(String obsMedicas) {
        this.obsMedicas = obsMedicas;
    }

    public String getNomeAutorizado() {
        return nomeAutorizado;
    }

    public void setNomeAutorizado(String nomeAutorizado) {
        this.nomeAutorizado = nomeAutorizado;
    }

    public String getParentesco() {
        return parentesco;
    }

    public void setParentesco(String parentesco) {
        this.parentesco = parentesco;
    }

    public String getTelefone() {
        return telefone;
    }

    public void setTelefone(String telefone) {
        this.telefone = telefone;
    }

    public Turma getTurma() {
        return turma;
    }

    public void setTurma(Turma turma) {
        this.turma = turma;
    }

    public Aluno() {
    }

    public Aluno(int idaluno, String nome, String cpf, String dataNascimento, String sexo, String obsMedicas, String nomeAutorizado, String parentesco, String telefone, Turma turma) {
        this.idaluno = idaluno;
        this.nome = nome;
        this.cpf = cpf;
        this.dataNascimento = dataNascimento;
        this.sexo = sexo;
        this.obsMedicas = obsMedicas;
        this.nomeAutorizado = nomeAutorizado;
        this.parentesco = parentesco;
        this.telefone = telefone;
        this.turma = turma;
    }


     public ArrayList<Aluno> getLista() throws Exception{
        AlunoDAO DAO = new AlunoDAO();
        return DAO.getLista();
    
    }
    
    public boolean gravar() throws Exception{
        AlunoDAO DAO = new AlunoDAO();
        return DAO.gravar(this);
    }
    
    public boolean excluir() throws Exception{
        AlunoDAO DAO = new AlunoDAO();
        return DAO.excluir(this);
    }
    
    public Aluno getCarregaPorID(int idaluno) throws Exception{
        AlunoDAO DAO = new AlunoDAO();
        return DAO.getCarregaPorID(idaluno);
    }
    
    
    
   

    
    
    
}
