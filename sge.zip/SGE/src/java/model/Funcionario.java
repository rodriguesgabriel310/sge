/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import java.util.ArrayList;
import persistencia.FuncionarioDAO;

/**
 *
 * @author gabriel.messias
 */
public class Funcionario {
    private int idfuncionario;
    private String nome;
    private String cpf;
    private String rg;
    private String cargo;
    private String fone;
    private String cep;
    private String endereco;
    private Usuario usuario;

    public int getIdfuncionario() {
        return idfuncionario;
    }

    public void setIdfuncionario(int idfuncionario) {
        this.idfuncionario = idfuncionario;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getCpf() {
        return cpf;
    }

    public void setCpf(String cpf) {
        this.cpf = cpf;
    }

    public String getRg() {
        return rg;
    }

    public void setRg(String rg) {
        this.rg = rg;
    }

    public String getCargo() {
        return cargo;
    }

    public void setCargo(String cargo) {
        this.cargo = cargo;
    }

    public String getFone() {
        return fone;
    }

    public void setFone(String fone) {
        this.fone = fone;
    }

    public String getCep() {
        return cep;
    }

    public void setCep(String cep) {
        this.cep = cep;
    }

    public String getEndereco() {
        return endereco;
    }

    public void setEndereco(String endereco) {
        this.endereco = endereco;
    }

    public Usuario getUsuario() {
        return usuario;
    }

    public void setUsuario(Usuario usuario) {
        this.usuario = usuario;
    }

    public Funcionario() {
    }

    public Funcionario(int idfuncionario, String nome, String cpf, String rg, String cargo, String fone, String cep, String endereco, Usuario usuario) {
        this.idfuncionario = idfuncionario;
        this.nome = nome;
        this.cpf = cpf;
        this.rg = rg;
        this.cargo = cargo;
        this.fone = fone;
        this.cep = cep;
        this.endereco = endereco;
        this.usuario = usuario;
    }

   public ArrayList<Funcionario> getLista() throws Exception{
        FuncionarioDAO DAO = new FuncionarioDAO();
        return DAO.getLista();
    
    }
    
    public boolean gravar() throws Exception{
        FuncionarioDAO DAO = new FuncionarioDAO();
        return DAO.gravar(this);
    }
    
    public boolean excluir() throws Exception{
        FuncionarioDAO DAO = new FuncionarioDAO();
        return DAO.excluir(this);
    }
    
    public Funcionario getCarregaPorID(int idfuncionario) throws Exception{
        FuncionarioDAO DAO = new FuncionarioDAO();
        return DAO.getCarregaPorID(idfuncionario);
    }
    
    
    
    
}
