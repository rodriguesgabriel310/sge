/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import java.util.ArrayList;
import persistencia.ResponsavelDAO;

/**
 *
 * @author Paulo farias
 */
public class Responsavel{
    private int idresponsavel;
    private String nome;
    private String cpf;
    private String rg;
    private String cep;
    private String endereco;
    private String escolaridade;
    private String profissao;
    private String foneResidencial;
    private String foneCelular;
    private String foneCelularDois;
    private String foneTrabalho;
    private ArrayList<Aluno> aluno;
    private ArrayList<Aluno> naoAluno;
   
    

   
    public void setNaoAluno(ArrayList<Aluno> naoAluno) {
        this.naoAluno = naoAluno;
    }

    public int getIdresponsavel() {
        return idresponsavel;
    }

    public void setIdresponsavel(int idresponsavel) {
        this.idresponsavel = idresponsavel;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getCpf() {
        return cpf;
    }

    public void setCpf(String cpf) {
        this.cpf = cpf;
    }

    public String getRg() {
        return rg;
    }

    public void setRg(String rg) {
        this.rg = rg;
    }

    public String getCep() {
        return cep;
    }

    public void setCep(String cep) {
        this.cep = cep;
    }

    public String getEndereco() {
        return endereco;
    }

    public void setEndereco(String endereco) {
        this.endereco = endereco;
    }

    public String getEscolaridade() {
        return escolaridade;
    }

    public void setEscolaridade(String escolaridade) {
        this.escolaridade = escolaridade;
    }

    public String getProfissao() {
        return profissao;
    }

    public void setProfissao(String profissao) {
        this.profissao = profissao;
    }

    public String getFoneResidencial() {
        return foneResidencial;
    }

    public void setFoneResidencial(String foneResidencial) {
        this.foneResidencial = foneResidencial;
    }

    public String getFoneCelular() {
        return foneCelular;
    }

    public void setFoneCelular(String foneCelular) {
        this.foneCelular = foneCelular;
    }

    public String getFoneCelularDois() {
        return foneCelularDois;
    }

    public void setFoneCelularDois(String foneCelularDois) {
        this.foneCelularDois = foneCelularDois;
    }

    public String getFoneTrabalho() {
        return foneTrabalho;
    }

    public void setFoneTrabalho(String foneTrabalho) {
        this.foneTrabalho = foneTrabalho;
    }
    
    public ArrayList<Aluno> getAluno() {
        return aluno;
    }

    public void setAluno(ArrayList<Aluno> aluno) {
        this.aluno = aluno;
    }

    public ArrayList<Aluno> getNaoAluno() {
        return naoAluno;
    }

    public Responsavel() {
    }

    public Responsavel(int idresponsavel, String nome, String cpf, String rg, String cep, String endereco, String escolaridade, String profissao, String foneResidencial, String foneCelular, String foneCelularDois, String foneTrabalho) {
        this.idresponsavel = idresponsavel;
        this.nome = nome;
        this.cpf = cpf;
        this.rg = rg;
        this.cep = cep;
        this.endereco = endereco;
        this.escolaridade = escolaridade;
        this.profissao = profissao;
        this.foneResidencial = foneResidencial;
        this.foneCelular = foneCelular;
        this.foneCelularDois = foneCelularDois;
        this.foneTrabalho = foneTrabalho;
    }

    
    public ArrayList<Responsavel> getLista() throws Exception{
        ResponsavelDAO DAO = new ResponsavelDAO();
        return DAO.getLista();
    
    }
    
    public boolean gravar() throws Exception{
        ResponsavelDAO DAO = new ResponsavelDAO();
        return DAO.gravar(this);
    }
    
    public boolean excluir() throws Exception{
        ResponsavelDAO DAO = new ResponsavelDAO();
        return DAO.excluir(this);
    }
    
    public Responsavel getCarregaPorID(int idresponsavel) throws Exception{
        ResponsavelDAO DAO = new ResponsavelDAO();
        return DAO.getCarregaPorID(idresponsavel);
    }
    
     public boolean vincular( int idresponsavel, int idaluno) throws Exception{
        ResponsavelDAO DAO = new ResponsavelDAO();
        return DAO.vincular(idresponsavel,idaluno);
    }
    public boolean desvincular(int idresponsavel, int idaluno) throws Exception{
        ResponsavelDAO DAO = new ResponsavelDAO();
        return DAO.desvincular(idresponsavel,idaluno);
    }
    
    
    
}
