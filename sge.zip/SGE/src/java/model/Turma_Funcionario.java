/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

/**
 *
 * @author gabriel.messias
 */
public class Turma_Funcionario {
    private Turma turma;
    private Funcionario funcionario;

    public Turma getTurma() {
        return turma;
    }

    public void setTurma(Turma turma) {
        this.turma = turma;
    }

    public Funcionario getFuncionario() {
        return funcionario;
    }

    public void setFuncionario(Funcionario funcionario) {
        this.funcionario = funcionario;
    }

    public Turma_Funcionario() {
    }

    public Turma_Funcionario(Turma turma, Funcionario funcionario) {
        this.turma = turma;
        this.funcionario = funcionario;
    }
    
    
}
