/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

/**
 *
 * @author 
 */
public class TurmaFuncionario {
    private int idturma;
    private int idfuncionario;
    

    public int getIdturma() {
        return idturma;
    }

    public void setIdturma(int idturma) {
        this.idturma = idturma;
    }

    public int getIdfuncionario() {
        return idfuncionario;
    }

    public void setIdfuncionario(int idfuncionario) {
        this.idfuncionario = idfuncionario;
    }

    public TurmaFuncionario() {
    }

    public TurmaFuncionario(int idturma, int idfuncionario) {
        this.idturma = idturma;
        this.idfuncionario = idfuncionario;
    }
    
    
    
    
    
}
