/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import persistencia.TurmaDAO;
import java.util.ArrayList;

/**
 *
 * @author Pintando o Sete
 */
public class Turma {
    
    private int idturma;
    private String tipoTurma;
    private String horario;
    private String dataInicio;
    private String dataFinal;   

   
    public int getIdturma() {
        return idturma;
    }

    public void setIdturma(int idturma) {
        this.idturma = idturma;
    }

    public String getTipoTurma() {
        return tipoTurma;
    }

    public void setTipoTurma(String tipoTurma) {
        this.tipoTurma = tipoTurma;
    }

    public String getHorario() {
        return horario;
    }

    public void setHorario(String horario) {
        this.horario = horario;
    }

    public String getDataInicio() {
        return dataInicio;
    }

    public void setDataInicio(String dataInicio) {
        this.dataInicio = dataInicio;
    }

    public String getDataFinal() {
        return dataFinal;
    }

    public void setDataFinal(String dataFinal) {
        this.dataFinal = dataFinal;
    }

    public Turma() {
    }

    public Turma(int idturma, String tipoTurma, String horario, String dataInicio, String dataFinal) {
        this.idturma = idturma;
        this.tipoTurma = tipoTurma;
        this.horario = horario;
        this.dataInicio = dataInicio;
        this.dataFinal = dataFinal;
    }   
    
    
    public ArrayList<Turma> getLista() throws Exception{
        TurmaDAO DAO = new TurmaDAO();
        return DAO.getLista();
    
    }
    
    public boolean gravar() throws Exception{
        TurmaDAO DAO = new TurmaDAO();
        return DAO.gravar(this);
    }
    
    public boolean excluir() throws Exception{
        TurmaDAO DAO = new TurmaDAO();
        return DAO.excluir(this);
        
    }
    
    public Turma getCarregaPorID(int idturma) throws Exception{
        TurmaDAO DAO = new TurmaDAO();
        return DAO.getCarregaPorID(idturma);
       
    }
   
    
}
