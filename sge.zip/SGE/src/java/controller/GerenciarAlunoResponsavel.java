/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import model.Responsavel;

/**
 *
 * @author Paulo farias
 */
public class GerenciarAlunoResponsavel extends HttpServlet {

   // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /** 
     * Handles the HTTP <code>GET</code> method.
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
       
        PrintWriter out = response.getWriter();
        String mensagem = "";
        String idresponsavel = request.getParameter("idresponsavel");
        String acao = request.getParameter("acao");
        
        try{
            if(acao.equals("gerenciar")){       
                Responsavel res = new Responsavel();
                res = res.getCarregaPorID(Integer.parseInt(idresponsavel));
                if(res.getIdresponsavel()>0){
                    RequestDispatcher disp = getServletContext().getRequestDispatcher("/form_aluno_responsavel.jsp");
                    request.setAttribute("responsavel", res);
                    disp.forward(request, response);
                }else{
                    mensagem = "Responsavel não encontrado";
                }
                }
            
            if(acao.equals("desvincular")){ 
                String idaluno = request.getParameter("idaluno");
                if(idaluno.equals("")||idaluno.isEmpty())
                    mensagem = "O aluno deve ser selecionado";
                else{
                    Responsavel res = new Responsavel();
                    if(res.desvincular(Integer.parseInt(idresponsavel), Integer.parseInt(idaluno))){
                        mensagem = "Desvinculado com sucesso";
                    }else{
                        mensagem = "Erro ao desvincular";
                    }
                }
                  } 

        
        }catch(Exception e){
            out.print(e);
        }
        out.println("<script type='text/javascript'>");
        out.println("alert('"+mensagem+"');");
        out.println("location.href='gerenciar_aluno_responsavel.do?acao=gerenciar&idresponsavel="+idresponsavel+"';");
        out.println("</script>");
        
    }

    /** 
     * Handles the HTTP <code>POST</code> method.
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        PrintWriter out = response.getWriter();
        String mensagem ="";
        String idaluno = request.getParameter("idaluno");
        String idresponsavel = request.getParameter("idresponsavel");
        
        try{
            if(idaluno.equals("")|| idaluno.isEmpty() || idresponsavel.equals("")||idresponsavel.isEmpty())
                mensagem = "Campos Obrigatorios devem ser selecionados";
            else{
                Responsavel res = new Responsavel();
                if(res.vincular(Integer.parseInt(idresponsavel), Integer.parseInt(idaluno))){
                    mensagem = "Vinculado com sucesso!";
                }else{
                    mensagem = "Erro ao vincular";
                }
            }
        }catch(Exception e){
            out.print(e);
            
        }
        out.println("<script type='text/javascript'>");
        out.println("alert('"+mensagem+"');");
        out.println("location.href='gerenciar_aluno_responsavel.do?acao=gerenciar&idresponsavel="+idresponsavel+"';");
        out.println("</script>");
        
    }

    /** 
     * Returns a short description of the servlet.
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>
}
