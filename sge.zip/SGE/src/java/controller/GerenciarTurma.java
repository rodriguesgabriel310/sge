/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import model.Turma;

/**
 *
 * @author Administrador
 */
public class GerenciarTurma extends HttpServlet {

    

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /** 
     * Handles the HTTP <code>GET</code> method.
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        PrintWriter out = response.getWriter();
        String mensagem = "";
        int idturma = Integer.parseInt(request.getParameter("idturma"));
        String acao = request.getParameter("acao");
        Turma t = new Turma();
        try{
            if(acao.equals("alterar")){
                Turma novo = new Turma();
                novo = t.getCarregaPorID(idturma);
                if(novo.getIdturma()>0){
                    RequestDispatcher disp = 
              getServletContext().getRequestDispatcher("/form_turma.jsp");
                    request.setAttribute("turma", novo);
                    disp.forward(request, response);
                }else{
                    mensagem = "Turma não encontrada";
                }
                    
            }
            if(acao.equals("excluir")){
                if(idturma!=0){
                    t.setIdturma(idturma);
                    if(t.excluir()){
                        mensagem="Excluido com sucesso";
                    }else{
                        mensagem ="Erro ao excluir";
                    }
                }
                    
            
            }
        
        }catch(Exception e){
            out.println(e);
            mensagem = "Erro ao acessar o banco";
        }
        out.println("<script type='text/javascript'>");
        out.println("alert('"+mensagem+"');");
        out.println("location.href='listar_turma.jsp';");
        out.println("</script>");
    }

    /** 
     * Handles the HTTP <code>POST</code> method.
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        PrintWriter out = response.getWriter();
        String idturma = request.getParameter("idturma");
        String tipoTurma = request.getParameter("tipoTurma");
        String horario = request.getParameter("horario");
        String dataInicio = request.getParameter("dataInicio");
        String dataFinal = request.getParameter("dataFinal");
        String mensagem = "";
        
        Turma t = new Turma();
        if(!idturma.isEmpty())
        t.setIdturma(Integer.parseInt(idturma));
        t.setTipoTurma(tipoTurma);
        t.setHorario(horario);
        t.setDataInicio(dataInicio);
        t.setDataFinal(dataFinal);
        
        try{
            if(tipoTurma.equals("")||horario.equals("")||dataInicio.equals("")||dataFinal.equals("")){
              mensagem = "Todos os campos devem ser preenchidos";
            }else{
                if(t.gravar()){                    
                    mensagem ="Gravado com sucesso";
                }else{
                    mensagem = "Erro ao gravar";
                }
            }
        
        }catch(Exception e){
            out.print(e);
            mensagem = "Erro ao gravar no banco";
        }
        out.println("<script type='text/javascript'>");
        out.println("alert('"+mensagem+"');");
        out.println("location.href='listar_turma.jsp';");
        out.println("</script>");
    }

    /** 
     * Returns a short description of the servlet.
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>
}
