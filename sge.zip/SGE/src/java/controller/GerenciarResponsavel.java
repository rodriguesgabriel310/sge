/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import model.Responsavel;

/**
 *
 * @author Administrador
 */
public class GerenciarResponsavel extends HttpServlet {

    

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /** 
     * Handles the HTTP <code>GET</code> method.
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        PrintWriter out = response.getWriter();
        String mensagem = "";
        int idresponsavel = Integer.parseInt(request.getParameter("idresponsavel"));
        String acao = request.getParameter("acao");
        Responsavel r = new Responsavel();
        try{
            if(acao.equals("alterar")){
                Responsavel novo = new Responsavel();
                novo = r.getCarregaPorID(idresponsavel);
                if(novo.getIdresponsavel()>0){
                    RequestDispatcher disp = 
              getServletContext().getRequestDispatcher("/form_responsavel.jsp");
                    request.setAttribute("responsavel", novo);
                    disp.forward(request, response);
                }else{
                    mensagem = "Responsável não encontrado";
                }
                    
            }
            if(acao.equals("excluir")){
                if(idresponsavel!=0){
                    r.setIdresponsavel(idresponsavel);
                    if(r.excluir()){
                        mensagem="Excluido com sucesso";
                    }else{
                        mensagem ="Erro ao excluir";
                    }
                }
                    
            
            }
        
        }catch(Exception e){
            out.println(e);
            mensagem = "Erro ao acessar o banco";
        }
        out.println("<script type='text/javascript'>");
        out.println("alert('"+mensagem+"');");
        out.println("location.href='listar_responsavel.jsp';");
        out.println("</script>");
    }

    /** 
     * Handles the HTTP <code>POST</code> method.
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        PrintWriter out = response.getWriter();
        String idresponsavel = request.getParameter("idresponsavel");
        String nome = request.getParameter("nome");
        String cpf = request.getParameter("cpf");
        String rg = request.getParameter("rg");
        String cep = request.getParameter("cep");
        String endereco = request.getParameter("endereco");
        String escolaridade = request.getParameter("escolaridade");
        String profissao = request.getParameter("profissao");
        String foneResidencial = request.getParameter("foneResidencial");
        String foneCelular = request.getParameter("foneCelular");
        String foneCelularDois = request.getParameter("foneCelularDois");
        String foneTrabalho = request.getParameter("foneTrabalho");
        String mensagem = "";
        
        Responsavel r = new Responsavel();
        if(!idresponsavel.isEmpty())
        r.setIdresponsavel(Integer.parseInt(idresponsavel));
        r.setNome(nome);
        r.setCpf(cpf);
        r.setRg(rg);
        r.setCep(cep);
        r.setEndereco(endereco);
        r.setEscolaridade(escolaridade);
        r.setProfissao(profissao);
        r.setFoneResidencial(foneResidencial);
        r.setFoneCelular(foneCelular);
        r.setFoneCelularDois(foneCelularDois);
        r.setFoneTrabalho(foneTrabalho);
        try{
            if(nome.equals("")||cpf.equals("")||rg.equals("")||cep.equals("")||endereco.equals("")||escolaridade.equals("")
                    ||profissao.equals("")||foneResidencial.equals("")||foneCelular.equals("")){
              mensagem = "Todos os campos devem ser preenchidos";
            }else{
                if(r.gravar()){                    
                    mensagem ="Gravado com sucesso";
                }else{
                    mensagem = "Erro ao gravar";
                }
            }
        
        }catch(Exception e){
            out.print(e);
            mensagem = "Erro ao gravar no banco";
        }
        out.println("<script type='text/javascript'>");
        out.println("alert('"+mensagem+"');");
        out.println("location.href='listar_responsavel.jsp';");
        out.println("</script>");
    }

    /** 
     * Returns a short description of the servlet.
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>
}
