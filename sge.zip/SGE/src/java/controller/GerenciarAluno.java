/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import model.Aluno;
import model.Turma;

/**
 *
 * @author Perfeito
 */
public class GerenciarAluno extends HttpServlet {

    

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /** 
     * Handles the HTTP <code>GET</code> method.
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        PrintWriter out = response.getWriter();
        String mensagem = "";
        int idaluno = Integer.parseInt(request.getParameter("idaluno"));
        String acao = request.getParameter("acao");
        Aluno a = new Aluno();
        try{
            if(acao.equals("alterar")){
                Aluno novo = new Aluno();
                novo = a.getCarregaPorID(idaluno);
                if(novo.getIdaluno()>0){
                    RequestDispatcher disp = 
              getServletContext().getRequestDispatcher("/form_aluno.jsp");
                    request.setAttribute("aluno", novo);
                    disp.forward(request, response);
                }else{
                    mensagem = "Aluno não encontrado";
                }
                    
            }
            if(acao.equals("excluir")){
                if(idaluno!=0){
                    a.setIdaluno(idaluno);
                    if(a.excluir()){
                        mensagem="Excluido com sucesso";
                    }else{
                        mensagem ="Erro ao excluir";
                    }
                }
                    
            
            }
        
        }catch(Exception e){
            out.println(e);
            mensagem = "Erro ao acessar o banco";
        }
        out.println("<script type='text/javascript'>");
        out.println("alert('"+mensagem+"');");
        out.println("location.href='listar_aluno.jsp';");
        out.println("</script>");
    }

    /** 
     * Handles the HTTP <code>POST</code> method.
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        PrintWriter out = response.getWriter();
        String idaluno = request.getParameter("idaluno");
        String nome = request.getParameter("nome");
        String cpf = request.getParameter("cpf");
        String dataNascimento = request.getParameter("dataNascimento");
        String sexo = request.getParameter("sexo");
        String obsMedicas = request.getParameter("obsMedicas");
        String nomeAutorizado = request.getParameter("nomeAutorizado");
        String parentesco = request.getParameter("parentesco");
        String telefone = request.getParameter("telefone");
        String idturma = request.getParameter("idturma");
        String mensagem = "";
        
        Aluno a = new Aluno();
        if(!idaluno.isEmpty())
        a.setIdaluno(Integer.parseInt(idaluno));
        a.setNome(nome);
        a.setCpf(cpf);
        a.setDataNascimento(dataNascimento);
        a.setSexo(sexo);
        a.setObsMedicas(obsMedicas);
        a.setNomeAutorizado(nomeAutorizado);
        a.setParentesco(parentesco);
        a.setTelefone(telefone);
        Turma t = new Turma();
        t.setIdturma(Integer.parseInt(idturma));
        a.setTurma(t);
       
        
        try{
            if(nome.equals("")||cpf.equals("")||dataNascimento.equals("")||sexo.equals("")||obsMedicas.equals("")
                    ||nomeAutorizado.equals("")||parentesco.equals("")||telefone.equals("")){
              mensagem = "Todos os campos devem ser preenchidos";
            }else{
                if(a.gravar()){
                    mensagem ="Gravado com sucesso";
                }else{
                    mensagem = "Erro ao gravar";
                }
            }
        
        }catch(Exception e){
            out.print(e);
            mensagem = "Erro ao gravar no banco";
        }
        out.println("<script type='text/javascript'>");
        out.println("alert('"+mensagem+"');");
        out.println("location.href='listar_aluno.jsp';");
        out.println("</script>");
    }

    /** 
     * Returns a short description of the servlet.
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>
}
