/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package persistencia;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import model.Aluno;
import model.Turma;

/**
 *
 * @author Perfeito
 */
public class AlunoDAO extends DataBaseDAO{
    
    public AlunoDAO() throws Exception{}
    
    public ArrayList<Aluno> getLista() throws Exception{
        
        ArrayList<Aluno> lista = new ArrayList<Aluno>();
        String sql = "SELECT * FROM aluno";
        this.conectar();
        Statement stm = conn.createStatement();
        ResultSet rs = stm.executeQuery(sql);
        while(rs.next()){
            Aluno a = new Aluno();
            a.setIdaluno(rs.getInt("idaluno"));
            a.setNome(rs.getString("nome"));
            a.setCpf(rs.getString("cpf"));
            a.setDataNascimento(rs.getString("dataNascimento"));
            a.setSexo(rs.getString("sexo"));
            a.setObsMedicas(rs.getString("obsMedicas"));
            a.setNomeAutorizado(rs.getString("nomeAutorizado"));
            a.setParentesco(rs.getString("parentesco"));
            a.setTelefone(rs.getString("telefone"));
            
            Turma t = new Turma();
            a.setTurma(t.getCarregaPorID(rs.getInt("idturma")));            
            lista.add(a);
        }     
        
        
        this.desconectar();
        return lista;
        
    }
    
    public boolean gravar(Aluno a){
       try{ 
            this.conectar();
            String sql;
            if(a.getIdaluno()==0)
                sql = "INSERT INTO aluno (nome, cpf, dataNascimento, sexo, obsMedicas, nomeAutorizado, parentesco, telefone, idturma )"
                    + "VALUES (?,?,?,?,?,?,?,?,?)";
            else
                sql= "UPDATE aluno SET nome=?, cpf=?, dataNascimento=?, sexo=?, obsMedicas=?, nomeAutorizado=?, parentesco=?,"
                        + "telefone=?, idturma=? WHERE idaluno=?";
            
            PreparedStatement pstm = conn.prepareStatement(sql);
            pstm.setString(1,a.getNome());
            pstm.setString(2,a.getCpf());
            pstm.setString(3,a.getDataNascimento());
            pstm.setString(4,a.getSexo());
            pstm.setString(5,a.getObsMedicas());
            pstm.setString(6,a.getNomeAutorizado());
            pstm.setString(7,a.getParentesco());
            pstm.setString(8,a.getTelefone());           
            pstm.setInt(9, a.getTurma().getIdturma());
            if(a.getIdaluno()>0)
                pstm.setInt(10,a.getIdaluno());
            pstm.execute();
            this.desconectar();
            return true;
       }catch(Exception e){
           System.out.println(e);
           return false;
       }
    }
    
    public Aluno getCarregaPorID(int idaluno) throws Exception{
        Aluno a = new Aluno();
        String sql = "SELECT a.*, t.tipoTurma FROM aluno a "
                + " INNER JOIN turma t ON "
                + " t.idturma = a.idturma WHERE a.idaluno=?";
        this.conectar();
        PreparedStatement pstm = conn.prepareStatement(sql);
        pstm.setInt(1,idaluno);
        ResultSet rs = pstm.executeQuery();
        if(rs.next()){
            a.setIdaluno(rs.getInt("idaluno"));
            a.setNome(rs.getString("nome"));
            a.setCpf(rs.getString("cpf"));
            a.setDataNascimento(rs.getString("dataNascimento"));
            a.setObsMedicas(rs.getString("obsMedicas"));
            a.setNomeAutorizado(rs.getString("nomeAutorizado"));
            a.setParentesco(rs.getString("parentesco"));
            a.setTelefone(rs.getString("telefone"));
            Turma t = new Turma();

            t.setIdturma(rs.getInt("a.idturma"));
            t.setTipoTurma(rs.getString("t.tipoTurma"));
        
          
            a.setTurma(t);
          
        }
        this.desconectar();
        return a;
    }

    
    public boolean excluir(Aluno a){
        try{
            
            this.conectar();
            String sql = "DELETE FROM aluno WHERE idaluno=?";
            PreparedStatement pstm = conn.prepareStatement(sql);
            pstm.setInt(1,a.getIdaluno());
            pstm.execute();
            this.desconectar();
            return true;
        }catch(Exception e){
            System.out.println(e);
            return false;
        }
    
    }
    
    
     public boolean vincular(int idaluno, int idresponsavel){
         try{
             String sql = "INSERT INTO aluno_responsavel (idaluno, idresponsavel) "
                     + " VALUES(?,?)";
             this.conectar();
             PreparedStatement pstm = conn.prepareStatement(sql);
             pstm.setInt(1,idaluno);
             pstm.setInt(2,idresponsavel);
             pstm.execute();
             this.desconectar();
             return true;
         }catch(Exception e){
             System.out.println(e);
             return false;
         }
     }
      public boolean desvincular(int idaluno, int idresponsavel){
         try{
             String sql = "DELETE FROM aluno_responsavel WHERE  "
                     + "idaluno=? AND idresponsavel=? ";
             this.conectar();
             PreparedStatement pstm = conn.prepareStatement(sql);
             pstm.setInt(1,idaluno);
             pstm.setInt(2,idresponsavel);
             pstm.execute();
             this.desconectar();
             return true;
         }catch(Exception e){
             System.out.println(e);
             return false;
         }
     }
}
