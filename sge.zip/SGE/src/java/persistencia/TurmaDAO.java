/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package persistencia;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import model.Turma;

/**
 *
 * @author Perfeito
 */
public class TurmaDAO extends DataBaseDAO {

    public TurmaDAO() throws Exception {
    }

    public ArrayList<Turma> getLista() throws Exception {

        ArrayList<Turma> lista = new ArrayList<Turma>();
        String sql = "SELECT * FROM turma";
        this.conectar();
        Statement stm = conn.createStatement();
        ResultSet rs = stm.executeQuery(sql);
        while (rs.next()) {
            Turma t = new Turma();
            t.setIdturma(rs.getInt("idturma"));
            t.setTipoTurma(rs.getString("tipoTurma"));
            t.setHorario(rs.getString("horario"));
            t.setDataInicio(rs.getString("dataInicio"));
            t.setDataFinal(rs.getString("dataFinal"));

            lista.add(t);
        }
        this.desconectar();
        return lista;

    }

    public boolean gravar(Turma t) {
        try {
            this.conectar();
            String sql;
            if (t.getIdturma()==0) 
                sql = "INSERT INTO turma (tipoTurma, horario, dataInicio, dataFinal)"
                        + "VALUES (?, ?, ?, ?)";
            else 
                sql = "UPDATE turma SET tipoTurma=?, horario=?, dataInicio=?, dataFinal=?"
                        + " WHERE idturma=?";
            

            PreparedStatement pstm = conn.prepareStatement(sql);
            pstm.setString(1, t.getTipoTurma());
            pstm.setString(2, t.getHorario());           
            pstm.setString(3, t.getDataInicio());
            pstm.setString(4, t.getDataFinal());
            
            if (t.getIdturma()>0) 
                pstm.setInt(5, t.getIdturma());
            
            pstm.execute();
            this.desconectar();
            return true;
        } catch (Exception e) {
            System.out.println(e);
            return false;
        }
    }

    public boolean excluir(Turma t) {
        try {
            this.conectar();
            String sql = "DELETE FROM turma WHERE idturma=?";
            PreparedStatement pstm = conn.prepareStatement(sql);
            pstm.setInt(1, t.getIdturma());
            pstm.execute();
            this.desconectar();
            return true;
        } catch (Exception e) {
            System.out.println(e);
            return false;
        }
    }

    public Turma getCarregaPorID(int idturma) throws Exception {
        Turma t = new Turma();
        String sql = "SELECT * FROM turma WHERE idturma=?";
        this.conectar();
        PreparedStatement pstm = conn.prepareStatement(sql);
        pstm.setInt(1, idturma);
        ResultSet rs = pstm.executeQuery();
        if (rs.next()) {
            t.setIdturma(rs.getInt("idturma"));
            t.setTipoTurma(rs.getString("tipoTurma"));
            t.setHorario(rs.getString("horario"));
            t.setDataInicio(rs.getString("dataInicio"));
            t.setDataFinal(rs.getString("dataFinal"));
        }
        this.desconectar();
        return t;
    }

}
