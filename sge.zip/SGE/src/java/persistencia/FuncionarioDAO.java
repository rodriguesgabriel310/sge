
package persistencia;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import model.Funcionario;
import model.Usuario;

/**
 *
 * @author 
 */
public class FuncionarioDAO extends DataBaseDAO {
    public FuncionarioDAO() throws Exception{}
   
    public ArrayList<Funcionario> getLista() throws Exception{
        
        ArrayList<Funcionario> lista = new ArrayList<>();
        String sql = "SELECT * FROM funcionario";
        this.conectar();
        Statement stm = conn.createStatement();
        ResultSet rs = stm.executeQuery(sql);
        while(rs.next()){
            Funcionario fun = new Funcionario();
            fun.setIdfuncionario(rs.getInt("idfuncionario"));            
            fun.setNome(rs.getString("nome"));
            fun.setCpf(rs.getString("cpf"));
            fun.setRg(rs.getString("rg"));
            fun.setCargo(rs.getString("cargo"));
            fun.setFone(rs.getString("fone"));
            fun.setCep(rs.getString("cep"));
            fun.setEndereco(rs.getString("endereco"));           
            
            Usuario u = new Usuario();
            fun.setUsuario(u.getCarregaPorID(rs.getInt("idusuario")));
            lista.add(fun);
        }
        this.desconectar();
        return lista;
        
    }
    
    
     public boolean gravar(Funcionario fun){
       try{ 
            this.conectar();
            String sql;
            if(fun.getIdfuncionario()==0)
               sql = "INSERT INTO funcionario (nome, cpf, rg, cargo, fone, cep, endereco, idusuario) "
                + "VALUES (?,?,?,?,?,?,?,?)";
            else
                sql= "UPDATE aluno SET nome=?, cpf=?, rg=?, cargo=?, fone=?, cep=?, endereco=?, idusuario=?"
                        +  "WHERE idaluno=?";
            
            PreparedStatement pstm = conn.prepareStatement(sql);
            pstm.setString(1,fun.getNome());
            pstm.setString(2,fun.getCpf());
            pstm.setString(3,fun.getRg());
            pstm.setString(4,fun.getCargo());
            pstm.setString(5,fun.getFone());
            pstm.setString(6,fun.getCep());
            pstm.setString(7,fun.getEndereco());
            pstm.setInt(8, fun.getUsuario().getIdusuario());
            if(fun.getIdfuncionario()>0)
                pstm.setInt(9,fun.getIdfuncionario());
            pstm.execute();
            this.desconectar();
            return true;
       }catch(Exception e){
           System.out.println(e);
           return false;
       }
    }
    
    
    
    
    
    
    public boolean excluir(Funcionario fun){
        try{
            this.conectar();
            //deletar usuario
            //String sql = "DELETE FROM usuario WHERE idusuario=?";
            
            //desativar usuario
            String sql = "DELETE FROM funcionario WHERE idfuncionario=? ";
            PreparedStatement pstm = conn.prepareStatement(sql);
            pstm.setInt(1, fun.getIdfuncionario());
            pstm.execute();
            this.desconectar();
            return true;
        }catch(Exception e){
            System.out.println(e);
            return false;
        }
    }
    
  
    

    public Funcionario getCarregaPorID(int idfuncionario) throws Exception{
        Funcionario fun = new Funcionario();
        String sql = "SELECT f.*, u.login FROM funcionario f "
                + " INNER JOIN usuario u ON "
                + " u.idusuario = f.idusuario WHERE f.idfuncionario=?";
        this.conectar();
        PreparedStatement pstm = conn.prepareStatement(sql);
        pstm.setInt(1,idfuncionario);
        ResultSet rs = pstm.executeQuery();
        if(rs.next()){
            fun.setIdfuncionario(rs.getInt("idfuncionario"));            
            fun.setNome(rs.getString("nome"));
            fun.setCpf(rs.getString("cpf"));
            fun.setRg(rs.getString("rg"));
            fun.setCargo(rs.getString("cargo"));
            fun.setFone(rs.getString("fone"));
            fun.setCep(rs.getString("cep"));
            fun.setEndereco(rs.getString("endereco"));           
            Usuario u = new Usuario();            
            u.setIdusuario(rs.getInt("f.idusuario"));         
            u.setLogin(rs.getString("u.login"));

            fun.setUsuario(u);
        }
        this.desconectar();
        return fun;
    }
    
}
    


   
