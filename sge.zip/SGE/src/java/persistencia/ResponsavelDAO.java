/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package persistencia;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import model.Aluno;
import model.Responsavel;
import model.Turma;

/**
 *
 * @author 
 */
public class ResponsavelDAO extends DataBaseDAO{
    
    public ResponsavelDAO() throws Exception{}
    
    public ArrayList<Responsavel> getLista() throws Exception{
        
        ArrayList<Responsavel> lista = new ArrayList<Responsavel>();
        String sql = "SELECT * FROM responsavel";
        this.conectar();
        Statement stm = conn.createStatement();
        ResultSet rs = stm.executeQuery(sql);
        while(rs.next()){
            Responsavel r = new Responsavel();
            r.setIdresponsavel(rs.getInt("idresponsavel"));
            r.setNome(rs.getString("nome"));
            r.setCpf(rs.getString("cpf"));
            r.setRg(rs.getString("rg"));
            r.setCep(rs.getString("cep"));
            r.setEndereco(rs.getString("endereco"));
            r.setEscolaridade(rs.getString("escolaridade"));
            r.setProfissao(rs.getString("profissao"));
            r.setFoneResidencial(rs.getString("foneResidencial"));
            r.setFoneCelular(rs.getString("foneCelular"));
            r.setFoneCelularDois(rs.getString("foneCelularDois"));
            r.setFoneTrabalho(rs.getString("foneTrabalho"));
            
            lista.add(r);
        }
        this.desconectar();
        return lista;
        
    }
    
    public boolean gravar(Responsavel r){
        try{
            this.conectar();
            String sql ;
            if(r.getIdresponsavel()==0)
                sql = "INSERT INTO responsavel (nome, cpf, rg, cep, endereco, escolaridade, profissao, foneResidencial, foneCelular, foneCelularDois, foneTrabalho)"
                + "VALUES (?,?,?,?,?,?,?,?,?,?,?)";
            else
                sql = "UPDATE responsavel SET nome=?, cpf=?, rg=?, cep=?, endereco=?, escolaridade=?, profissao=?, foneResidencial=?, foneCelular=?, foneCelularDois=?, foneTrabalho=?"
                        + " WHERE idresponsavel=?";
            PreparedStatement pstm = conn.prepareStatement(sql);
            pstm.setString(1,r.getNome());
            pstm.setString(2,r.getCpf());
            pstm.setString(3,r.getRg());
            pstm.setString(4,r.getCep());
            pstm.setString(5,r.getEndereco());
            pstm.setString(6,r.getEscolaridade());
            pstm.setString(7,r.getProfissao());
            pstm.setString(8,r.getFoneResidencial());
            pstm.setString(9,r.getFoneCelular());
            pstm.setString(10,r.getFoneCelularDois());
            pstm.setString(11,r.getFoneTrabalho());
            if(r.getIdresponsavel()>0)
                pstm.setInt(12,r.getIdresponsavel());
        
            pstm.execute();
            this.desconectar();
            return true;
        }catch(Exception e){
            System.out.println(e);
            return false;
        }
    }
    
    public boolean excluir(Responsavel r){
        try{
            this.conectar();
            String sql = "DELETE FROM responsavel WHERE idresponsavel=?";
            PreparedStatement pstm = conn.prepareStatement(sql);
            pstm.setInt(1, r.getIdresponsavel());
            pstm.execute();
            this.desconectar();
            return true;
        }catch(Exception e){
            System.out.println(e);
            return false;
        }
    }
    public Responsavel getCarregaPorID(int idresponsavel) throws Exception{
        Responsavel r = new Responsavel();
        String sql = "SELECT * FROM responsavel WHERE idresponsavel=?";
        this.conectar();
        PreparedStatement pstm = conn.prepareStatement(sql);
        pstm.setInt(1,idresponsavel);
        ResultSet rs = pstm.executeQuery();
        if(rs.next()){
            r.setIdresponsavel(rs.getInt("idresponsavel"));
            r.setNome(rs.getString("nome"));
            r.setCpf(rs.getString("cpf"));
            r.setRg(rs.getString("rg"));
            r.setCep(rs.getString("cep"));
            r.setEndereco(rs.getString("endereco"));
            r.setEscolaridade(rs.getString("escolaridade"));
            r.setProfissao(rs.getString("profissao"));
            r.setFoneResidencial(rs.getString("foneResidencial"));
            r.setFoneCelular(rs.getString("foneCelular"));
            r.setFoneCelularDois(rs.getString("foneCelularDois"));
            r.setFoneTrabalho(rs.getString("foneTrabalho"));
        }
        this.desconectar();
        return r;
    }
    
    public ArrayList<Aluno> alunosVinculadosPorPerfil(int id) throws Exception{
        
        ArrayList<Aluno> lista = new ArrayList<Aluno>();
        String sql = "SELECT a.* FROM aluno_responsavel as ar, "
                + "aluno as a WHERE ar.idaluno = a.idaluno AND "
                + "ar.idresponsavel =? ";
        this.conectar();
        PreparedStatement pstm = conn.prepareStatement(sql);
        pstm.setInt(1,id);
        ResultSet rs = pstm.executeQuery();
        while(rs.next()){
            Aluno al = new Aluno();
            al.setIdaluno(rs.getInt("a.idaluno"));
            al.setNome(rs.getString("a.nome"));
            al.setCpf(rs.getString("a.cpf"));
            al.setDataNascimento(rs.getString("a.dataNascimento"));
            al.setSexo(rs.getString("a.sexo"));
            al.setObsMedicas(rs.getString("a.obsMedicas"));
            al.setNomeAutorizado(rs.getString("a.nomeAutorizado"));
            al.setParentesco(rs.getString("a.parentesco"));
            al.setTelefone(rs.getString("a.telefone"));
            Turma t = new Turma();
            al.setTurma(t.getCarregaPorID(rs.getInt("a.idturma")));
            lista.add(al);
        }
        this.desconectar();
        return lista;
    
    }
    
     public ArrayList<Aluno> alunosNaoVinculadosPorPerfil(int idaluno) throws Exception{
        
        ArrayList<Aluno> lista = new ArrayList<Aluno>();
        String sql = "SELECT * FROM aluno WHERE idaluno "
                + " NOT IN ( SELECT idaluno FROM aluno_responsavel "
                            + " WHERE idresponsavel=? "
                         + ")";
        this.conectar();
        PreparedStatement pstm = conn.prepareStatement(sql);
        pstm.setInt(1,idaluno);
        ResultSet rs = pstm.executeQuery();
        while(rs.next()){
            Aluno a = new Aluno();
            a.setIdaluno(rs.getInt("idaluno"));
            a.setNome(rs.getString("nome"));
            a.setCpf(rs.getString("cpf"));
            a.setDataNascimento(rs.getString("dataNascimento"));
            a.setSexo(rs.getString("sexo"));
            a.setObsMedicas(rs.getString("obsMedicas"));
            a.setNomeAutorizado(rs.getString("nomeAutorizado"));
            a.setParentesco(rs.getString("parentesco"));
            a.setTelefone(rs.getString("telefone"));
            
            lista.add(a);
        }
        this.desconectar();
        return lista;
    
    }
    
    
     public boolean vincular(int idresponsavel, int idaluno){
         try{
             String sql = "INSERT INTO aluno_responsavel (idaluno, idresponsavel) "
                     + " VALUES(?,?)";
             this.conectar();
             PreparedStatement pstm = conn.prepareStatement(sql);
             pstm.setInt(1,idaluno);
             pstm.setInt(2,idresponsavel);
             pstm.execute();
             this.desconectar();
             return true;
         }catch(Exception e){
             System.out.println(e);
             return false;
         }
     }
      public boolean desvincular(int idresponsavel, int idaluno){
         try{
             String sql = "DELETE FROM aluno_responsavel WHERE  "
                     + "idaluno=? AND idresponsavel=? ";
             this.conectar();
             PreparedStatement pstm = conn.prepareStatement(sql);
             pstm.setInt(1,idaluno);
             pstm.setInt(2,idresponsavel);
             pstm.execute();
             this.desconectar();
             return true;
         }catch(Exception e){
             System.out.println(e);
             return false;
         }
     }
    
}
